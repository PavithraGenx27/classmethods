﻿using System;

namespace MyConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. Prime number or not");
            Console.WriteLine("2. Factorial of a number");
            Console.WriteLine("3. Reverse a string");
            Console.WriteLine("4. Parameters and return value");
            Console.WriteLine("5. Method Overloading");
            Console.WriteLine("6. Exit");
            Console.Write("Enter your choice: ");

            string choice = Console.ReadLine();
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    Primenumber();
                    break;
                case "2":
                    Factorial();
                    break;
                case "3":
                    ReverseString();
                    break;
                case "4":
                    Parameter();
                    break;
                case "5":
                    Overloading();
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }

            Console.WriteLine("\nPress any key to exit:");
            Console.ReadKey();
        }

        static void Primenumber()
        {
            Console.Write("Enter the limit: ");
            int limit = int.Parse(Console.ReadLine());

            for (int i = 2; i < limit; i++)
            {
                bool isPrime = true;
                for (int j = 2; j <= Math.Sqrt(i); j++)
                {
                    if (i % j == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }

                if (isPrime)
                {
                    Console.Write(i + " ");
                }
            }
            Console.WriteLine();
        }

        static void Factorial()
        {
            Console.Write("Factorial of: ");
            int num = int.Parse(Console.ReadLine());
            int fact = 1;

            while (num > 0)
            {
                fact = fact * num;
                num--;
            }

            Console.WriteLine("Factorial is: " + fact);
        }

        static void ReverseString()
        {
            Console.Write("Enter the word: ");
            string input = Console.ReadLine();

            string reverse = string.Empty;
            int length = input.Length - 1;

            while (length >= 0)
            {
                reverse = reverse + input[length];
                length--;
            }

            Console.WriteLine("Reversed string is: " + reverse);
        }

        static void Parameter()
        {
            Console.Write("Enter first number: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Enter second number: ");
            int b = int.Parse(Console.ReadLine());

            int result = Sum(a, b);
            Console.WriteLine("Result: " + result);
        }

        static int Sum(int a, int b)
        {
            return a + b;
        }

        static void Overloading()
        {
            Calculator calc = new Calculator();
            calc.Add(5, 10);
            calc.Add(5, 10, 15);
        }
    }

    
    class Calculator
    {
        public void Add(int A, int B)
        {
            Console.WriteLine("Result is: " + (A + B));
        }

        public void Add(int A, int B, int C)
        {
            Console.WriteLine("Result is: " + (A + B + C));
        }
    }
}
